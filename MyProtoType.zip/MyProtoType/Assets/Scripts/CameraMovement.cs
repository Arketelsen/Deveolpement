﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraMovement : MonoBehaviour
{
    private const float Y_ANGLE_MIN = -50.0f;
    private const float Y_ANGLE_MAX = 50.0f;

    [SerializeField] private Transform _lookAtPoint;
    [SerializeField] private Transform _cameraTransform;

    private Camera _cam;

    [SerializeField] private float _distance;

    private float _currentX;
    private float _currentY;
    [SerializeField] private float _sensitivityX;
    [SerializeField] private float _sensitivityY;


    // Start is called before the first frame update
    void Start()
    {
        _cameraTransform = transform;
        _cam = Camera.main;
    }

    private void Update()
    {
        _currentX += Input.GetAxis("Mouse X");
        _currentY += Input.GetAxis("Mouse Y");

        _currentY = Mathf.Clamp(_currentY, Y_ANGLE_MIN, Y_ANGLE_MAX);
    }

    // Update is called once per frame
    void LateUpdate()
    {
        Vector3 direction = new Vector3(0, 0, -_distance);
        Quaternion rotation = Quaternion.Euler(_currentY, _currentX, 0);
        _cameraTransform.position = _lookAtPoint.position + rotation * direction;
        _cameraTransform.LookAt(_lookAtPoint.position);
    }
}
